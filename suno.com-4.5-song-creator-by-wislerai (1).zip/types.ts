// Removed Genre, Mood enums and SongIdea interface as they are no longer used directly for input.
// The core input is now songTitle (optional) and styleDescription (string).

export interface GeneratedLyrics {
  title: string;
  lyricsBody: string;
}
