// GEMINI_LYRICS_MODEL remains, but GENRE_OPTIONS and MOOD_OPTIONS are removed.
export const GEMINI_LYRICS_MODEL = 'gemini-2.5-flash-preview-04-17';

// Removed GENRE_OPTIONS and MOOD_OPTIONS as they are no longer used.
