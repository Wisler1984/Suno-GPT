import React, { useState, useCallback, useEffect } from 'react';
import { GeneratedLyrics } from './types';
// Removed Genre, Mood, GENRE_OPTIONS, MOOD_OPTIONS as they are replaced by styleDescription
import { generateLyricsAI } from './services/geminiService';
import Button from './components/Button';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorMessage from './components/ErrorMessage';
import LyricsDisplay from './components/LyricsDisplay';
import AudioPlayerMock from './components/AudioPlayerMock'; 
// Icons
import PlayIcon from './components/icons/PlayIcon'; // Re-using for Create button
import CopyIcon from './components/icons/CopyIcon';
import ResetIcon from './components/icons/ResetIcon';

const App: React.FC = () => {
  const [songTitle, setSongTitle] = useState<string>("");
  const [styleDescription, setStyleDescription] = useState<string>("");
  
  const [generatedLyrics, setGeneratedLyrics] = useState<GeneratedLyrics | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [showAudioPlayer, setShowAudioPlayer] = useState<boolean>(false); // Keep mock player for now
  const [copied, setCopied] = useState<boolean>(false);

  const apiKeyExists = process.env.API_KEY && process.env.API_KEY.length > 0;

  const handleGenerateLyrics = useCallback(async () => {
    if (!styleDescription.trim()) {
      setError("Please enter a style description for your song.");
      return;
    }
    if (!apiKeyExists) {
      setError("API Key is not configured. Please set the API_KEY environment variable.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedLyrics(null);
    setShowAudioPlayer(false);
    setCopied(false);

    try {
      const lyrics = await generateLyricsAI({ songTitle, styleDescription });
      setGeneratedLyrics(lyrics);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("An unknown error occurred during lyric generation.");
      }
    } finally {
      setIsLoading(false);
    }
  }, [songTitle, styleDescription, apiKeyExists]);

  const handleCopyLyrics = useCallback(() => {
    if (generatedLyrics) {
      const textToCopy = `${generatedLyrics.title}\n\n${generatedLyrics.lyricsBody}`;
      navigator.clipboard.writeText(textToCopy)
        .then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 2000); // Hide message after 2s
        })
        .catch(err => {
          console.error("Failed to copy lyrics: ", err);
          setError("Failed to copy lyrics to clipboard.");
        });
    }
  }, [generatedLyrics]);

  const handleReset = useCallback(() => {
    setSongTitle("");
    setStyleDescription("");
    setGeneratedLyrics(null);
    setError(null);
    setIsLoading(false);
    setShowAudioPlayer(false);
    setCopied(false);
  }, []);

  // Common styles
  const inputBaseStyles = "w-full bg-[#101827] border border-slate-700 rounded-md text-slate-200 placeholder-slate-500 focus:ring-2 focus:ring-[#22D3EE] focus:border-[#22D3EE] transition-colors duration-150 ease-in-out shadow-sm";
  const labelStyles = "block mb-2 text-sm font-medium text-sky-300 font-orbitron tracking-wider";

  useEffect(() => {
    // Preload API key status message if not set
    if (!apiKeyExists) {
        setError("API_KEY is not set. This application requires an API key to function.");
    }
  }, [apiKeyExists]);


  return (
    <div className="min-h-screen flex flex-col bg-[#0A0F1A]">
      {/* Header */}
      <header className="py-5 px-4 sm:px-6 lg:px-8 border-b border-slate-700/50">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h1 className="text-4xl font-orbitron font-bold text-glow-cyan">
            WISLERAI
          </h1>
          <div className="text-sm font-orbitron text-sky-400 px-3 py-1 border border-sky-600 rounded-md">
            v4.5
          </div>
        </div>
      </header>

      <main className="flex-grow container mx-auto px-4 py-8 max-w-7xl">
        {!apiKeyExists && !error && ( // Show only if no other error is actively displayed by user action
           <div className="mb-6">
             <ErrorMessage title="Configuration Error" message="API_KEY is not set. This application requires an API key to function." />
           </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Column: Inputs */}
          <section className="bg-[#101827] p-6 rounded-lg shadow-2xl border border-slate-700/50 space-y-6">
            <div>
              <label htmlFor="songTitle" className={labelStyles}>
                Song Title (Optional)
              </label>
              <input
                type="text"
                id="songTitle"
                value={songTitle}
                onChange={(e) => setSongTitle(e.target.value)}
                placeholder="Enter your song title"
                className={`${inputBaseStyles} p-3`}
                disabled={isLoading || !apiKeyExists}
              />
            </div>

            <div>
              <label htmlFor="styleDescription" className={labelStyles}>
                Style Description
              </label>
              <textarea
                id="styleDescription"
                value={styleDescription}
                onChange={(e) => setStyleDescription(e.target.value)}
                placeholder="e.g., Epic cinematic orchestral piece about a space battle, Hans Zimmer style with heavy drums and choir..."
                rows={8}
                className={`${inputBaseStyles} p-3 resize-y`}
                disabled={isLoading || !apiKeyExists}
              />
              <p className="mt-2 text-xs text-slate-400">Describe the genre, mood, tempo, key instruments, artists for inspiration, or any specific elements.</p>
            </div>
            
            <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4 pt-4">
              <Button 
                type="button"
                onClick={handleGenerateLyrics}
                disabled={isLoading || !styleDescription.trim() || !apiKeyExists}
                leftIcon={<PlayIcon className="w-5 h-5 mr-1"/>}
                variant="accent"
                size="large"
                className="w-full sm:w-auto flex-grow"
              >
                {isLoading ? 'CREATING...' : 'CREATE SONG'}
              </Button>
              <Button
                type="button"
                onClick={handleReset}
                variant="secondary"
                size="large"
                leftIcon={<ResetIcon className="w-5 h-5 mr-1"/>}
                className="w-full sm:w-auto"
                disabled={isLoading}
              >
                RESET
              </Button>
            </div>
          </section>

          {/* Right Column: Output */}
          <section className="space-y-6">
            {isLoading && <LoadingSpinner />}
            {error && <ErrorMessage message={error} title="Error"/>}
            
            {generatedLyrics && !isLoading && (
              <div className="animate-fadeIn">
                <LyricsDisplay lyricsData={generatedLyrics} />
                <div className="mt-6 flex flex-col sm:flex-row items-center space-y-3 sm:space-y-0 sm:space-x-4">
                  <Button 
                    onClick={handleCopyLyrics}
                    variant="secondary"
                    leftIcon={<CopyIcon className="w-5 h-5 mr-1"/>}
                    disabled={copied}
                    className="w-full sm:w-auto"
                  >
                    {copied ? 'COPIED!' : 'COPY SONG'}
                  </Button>
                  <Button 
                    onClick={() => setShowAudioPlayer(prev => !prev)} 
                    variant="secondary"
                    className="w-full sm:w-auto"
                  >
                    {showAudioPlayer ? "HIDE PLAYER" : "SIMULATE AUDIO"}
                  </Button>
                </div>
                 {showAudioPlayer && <AudioPlayerMock />}
              </div>
            )}
            {!generatedLyrics && !isLoading && !error && (
                 <div className="text-center py-10 px-6 bg-[#101827] rounded-lg border border-slate-700/50">
                    <h3 className="font-orbitron text-xl text-sky-400">Your Masterpiece Awaits</h3>
                    <p className="text-slate-400 mt-2">Fill in the details and click "Create Song" to generate your lyrics.</p>
                </div>
            )}
          </section>
        </div>
      </main>

      <footer className="text-center py-6 text-sm text-slate-500 border-t border-slate-700/50">
        <p>&copy; {new Date().getFullYear()} WISLERAI. All rights reserved. AI-Powered Creativity.</p>
      </footer>
    </div>
  );
};

export default App;