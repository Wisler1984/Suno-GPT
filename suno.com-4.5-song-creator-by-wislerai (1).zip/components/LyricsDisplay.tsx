import React from 'react';
import { GeneratedLyrics } from '../types';

interface LyricsDisplayProps {
  lyricsData?: GeneratedLyrics;
  titleClassName?: string;
  bodyClassName?: string;
}

const LyricsDisplay: React.FC<LyricsDisplayProps> = ({ 
  lyricsData,
  titleClassName = "font-orbitron text-3xl font-bold text-[#22D3EE] mb-6 text-glow-cyan",
  bodyClassName = "text-slate-300 whitespace-pre-wrap leading-relaxed text-sm sm:text-base prose-p:my-2 prose-headings:my-3" 
}) => {
  if (!lyricsData) {
    return null;
  }

  // Sanitize or ensure lyricsBody doesn't contain harmful HTML if it's not controlled
  // For now, assuming basic text with newlines.
  const formattedLyricsBody = lyricsData.lyricsBody
    .split('\n')
    .map(line => line.trim() === '' ? '<br />' : `<p>${line}</p>`) // More semantic than just br for paragraphs
    .join('');


  return (
    <div className="bg-[#101827] p-6 rounded-lg shadow-xl border border-[#22D3EE]/20 animate-fadeIn">
      <h2 className={titleClassName}>
        {lyricsData.title || "Untitled Song"}
      </h2>
      <div 
        className={bodyClassName}
        dangerouslySetInnerHTML={{ __html: lyricsData.lyricsBody.replace(/\n\n/g, '<br /><br />').replace(/\n/g, '<br />') }}
      />
    </div>
  );
};

export default LyricsDisplay;