import React from 'react';

interface ErrorMessageProps {
  message: string;
  title?: string;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ message, title = "An error occurred" }) => {
  if (!message) return null;

  return (
    <div className="bg-red-900/70 border border-red-700 text-red-200 px-4 py-3 rounded-lg relative shadow-md my-6 animate-fadeIn" role="alert">
      <strong className="font-bold font-orbitron block sm:inline">{title}: </strong>
      <span className="block sm:inline">{message}</span>
    </div>
  );
};

export default ErrorMessage;