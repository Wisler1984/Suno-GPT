import React, { useState, useEffect } from 'react';
import PlayIcon from './icons/PlayIcon';
import PauseIcon from './icons/PauseIcon';
import Button from './Button';

const AudioPlayerMock: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout | undefined;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 2; 
        });
      }, 200);
    } else {
      if (progress >= 100) setProgress(0);
    }
    return () => clearInterval(interval);
  }, [isPlaying, progress]);

  const togglePlay = () => {
    if (isPlaying) {
      setIsPlaying(false);
    } else {
      if(progress >= 100) setProgress(0); 
      setIsPlaying(true);
    }
  };

  return (
    <div className="mt-6 p-4 sm:p-6 bg-[#101827] rounded-lg shadow-xl border border-[#22D3EE]/20 animate-fadeIn">
      <h3 className="text-lg font-orbitron font-semibold text-sky-400 mb-4">Audio Playback (Mock)</h3>
      <div className="flex items-center space-x-4">
        <Button onClick={togglePlay} variant="secondary" className="p-2.5" aria-label={isPlaying ? "Pause audio" : "Play audio"}>
          {isPlaying ? <PauseIcon className="w-5 h-5" /> : <PlayIcon className="w-5 h-5" />}
        </Button>
        <div className="w-full bg-slate-700 rounded-full h-2.5 overflow-hidden">
          <div
            className="bg-sky-500 h-2.5 rounded-full transition-all duration-200 ease-linear"
            style={{ width: `${progress}%` }}
            aria-valuenow={progress}
            aria-valuemin={0}
            aria-valuemax={100}
            role="progressbar"
          ></div>
        </div>
        <span className="text-sm text-slate-400 w-12 text-right">{Math.round(progress)}%</span>
      </div>
      {isPlaying && (
        <p className="text-xs text-slate-500 mt-2 text-center animate-pulse">Simulating audio playback...</p>
      )}
    </div>
  );
};

export default AudioPlayerMock;