
import React from 'react';

interface SparklesIconProps {
  className?: string;
}

const SparklesIcon: React.FC<SparklesIconProps> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className || "w-5 h-5"}
  >
    <path d="M12 .5l2.16 4.96L19.5 6l-3.78 3.7.88 5.3L12 12.5l-4.6 2.5.88-5.3L3.5 6l5.34-.54L12 .5zm0 8l-1.12 2.58L8.5 12l1.94 1.92-.46 2.58L12 15.17l2.02 1.33-.46-2.58L15.5 12l-2.38-.42L12 8.5zm6.91 3.99l-1.03 2.36-2.36 1.03 2.36 1.03 1.03 2.36 1.03-2.36 2.36-1.03-2.36-1.03-1.03-2.36zM5.09 12.39l-1.03 2.36-2.36 1.03 2.36 1.03 1.03 2.36 1.03-2.36 2.36-1.03-2.36-1.03-1.03-2.36z" />
  </svg>
);

export default SparklesIcon;
