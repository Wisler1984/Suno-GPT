import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'danger' | 'accent';
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  size?: 'small' | 'medium' | 'large';
}

const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  leftIcon, 
  rightIcon, 
  className, 
  size = 'medium',
  ...props 
}) => {
  const baseStyles = "font-orbitron rounded-md font-semibold shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#0A0F1A] transition-all duration-150 ease-in-out inline-flex items-center justify-center space-x-2 disabled:opacity-60 disabled:cursor-not-allowed disabled:shadow-none";
  
  let variantStyles = "";
  switch (variant) {
    case 'primary': // Cyan/Blue
      variantStyles = "bg-sky-500 hover:bg-sky-600 text-white focus:ring-sky-400";
      break;
    case 'secondary': // Darker, subtle
      variantStyles = "bg-slate-700 hover:bg-slate-600 text-slate-100 focus:ring-slate-500 border border-slate-600 hover:border-slate-500";
      break;
    case 'danger':
      variantStyles = "bg-red-600 hover:bg-red-700 text-white focus:ring-red-500";
      break;
    case 'accent': // Orange/Amber for "Create" button
      variantStyles = "bg-[#FF6B00] hover:bg-[#E05A00] text-white focus:ring-[#FF6B00] shadow-[0_0_15px_rgba(255,107,0,0.5)] hover:shadow-[0_0_20px_rgba(255,107,0,0.7)]";
      break;
  }

  let sizeStyles = "";
  switch(size) {
    case 'small':
      sizeStyles = "px-3 py-1.5 text-xs";
      break;
    case 'medium':
      sizeStyles = "px-5 py-2.5 text-sm";
      break;
    case 'large':
      sizeStyles = "px-8 py-3 text-base";
      break;
  }

  return (
    <button
      className={`${baseStyles} ${variantStyles} ${sizeStyles} ${className || ''}`}
      {...props}
    >
      {leftIcon}
      <span>{children}</span>
      {rightIcon}
    </button>
  );
};

export default Button;