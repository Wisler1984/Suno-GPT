import React from 'react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex flex-col justify-center items-center py-12 bg-[#101827]/50 rounded-lg my-6">
      <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-[#22D3EE]"></div>
      <p className="ml-4 mt-4 text-sky-300 text-lg font-orbitron tracking-wider animate-pulse">
        CREATING YOUR SONG...
      </p>
    </div>
  );
};

export default LoadingSpinner;