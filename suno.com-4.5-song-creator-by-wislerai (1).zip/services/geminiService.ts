import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GeneratedLyrics } from '../types'; // Assuming SongIdea is no longer used directly here
import { GEMINI_LYRICS_MODEL } from '../constants';

const API_KEY = process.env.API_KEY;

interface LyricGenerationParams {
  styleDescription: string;
  songTitle?: string;
}

export const generateLyricsAI = async ({ styleDescription, songTitle }: LyricGenerationParams): Promise<GeneratedLyrics> => {
  if (!API_KEY) {
    console.error("API_KEY is not set in environment variables.");
    throw new Error("API_KEY is missing. Please configure it in your environment.");
  }

  const ai = new GoogleGenAI({ apiKey: API_KEY });

  let titleInstruction = "Generate a creative and fitting song title based on the style and lyrics.";
  if (songTitle && songTitle.trim() !== "") {
    titleInstruction = `The user suggests the title "${songTitle}". You can use this as inspiration or refine it if you generate a better fitting one based on the lyrics. Ensure the final title is included in the JSON.`;
  }

  const prompt = `
You are an expert song-writing AI. Your task is to generate compelling song lyrics and a title based on the provided style description.
Return your response STRICTLY as a JSON object with the following structure:
{
  "title": "A fitting and creative song title",
  "lyricsBody": "The full lyrics including verses, chorus, and optionally a bridge or outro. Ensure standard song structure and use newline characters (\\n) for line breaks, and double newlines (\\n\\n) to separate sections (e.g., Verse 1\\n\\nChorus\\n\\nVerse 2\\n\\nChorus\\n\\nBridge\\n\\nChorus)."
}

Do NOT include any explanatory text before or after the JSON object.
Do NOT use markdown code fences (like \`\`\`json) around the JSON object.

Song Details:
- Style & Theme Description: ${styleDescription}
- Title Instruction: ${titleInstruction}

Generate the song now.
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_LYRICS_MODEL,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.75, // Slightly higher for more creative/varied output
        topP: 0.95,
        topK: 40,
      },
    });
    
    const rawText = response.text;
    
    let jsonStr = rawText.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }

    const parsedData = JSON.parse(jsonStr);

    if (parsedData && typeof parsedData.title === 'string' && typeof parsedData.lyricsBody === 'string') {
      return parsedData as GeneratedLyrics;
    } else {
      console.error("Generated JSON does not match expected structure:", parsedData);
      throw new Error("AI response format is incorrect. Expected title and lyricsBody.");
    }
  } catch (error) {
    console.error("Error generating lyrics with AI:", error);
    if (error instanceof Error) {
        // Check for common API errors if possible, e.g., quota, invalid key
        if (error.message.includes("API key not valid")) {
            throw new Error("Invalid API Key. Please check your configuration.");
        }
         throw new Error(`Failed to generate lyrics: ${error.message}`);
    }
    throw new Error("An unknown error occurred while generating lyrics.");
  }
};